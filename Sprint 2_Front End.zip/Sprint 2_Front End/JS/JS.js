
// Lista de páginas do seu site
const pages = [
    { name: "Mapa interativo", url: "mapa_interativo.html" },
    { name: "Status das linhas", url: "status_linha.html" },
    { name: "Comércios locais", url: "estacao.html" },
    { name: "Assistente virtual", url: "chatbot.html" },
];

// Função para buscar as páginas e abrir em nova guia
function search() {
    const query = document.getElementById("searchbar").value.toLowerCase();
    const resultsContainer = document.getElementById("results-container");

    // Encontra a primeira página que corresponde ao termo pesquisado
    const result = pages.find(page => page.name.toLowerCase().includes(query));

    // Limpa o container de resultados
    resultsContainer.innerHTML = "";

    if (result) {
        // Abre a URL da página encontrada em uma nova aba
        window.open(result.url, "_blank");
    } else {
        // Exibe uma mensagem se a página não foi encontrada
        resultsContainer.innerHTML = "Nenhuma página encontrada.";
    }
}

// Evento para acionar a busca apenas ao pressionar Enter
document.getElementById("searchbar").addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        searchPages();
    }
});
